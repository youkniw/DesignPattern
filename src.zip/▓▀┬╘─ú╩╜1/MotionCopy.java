package 策略模式1;

/**
 * @Author Lang wenchong
 * @Date 2021/11/4 16:12
 * @Version 1.0
 */
public class MotionCopy implements CopyInterface {

    @Override
    public void Copy() {
        System.out.println("使用CR/CT-Motion拷贝算法进行数据拷贝");
    }
}
