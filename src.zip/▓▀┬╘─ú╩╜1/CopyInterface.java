package 策略模式1;

/**
 * @Author Lang wenchong
 * @Date 2021/11/4 16:10
 * @Version 1.0
 */
public interface CopyInterface {
    void Copy();
}
