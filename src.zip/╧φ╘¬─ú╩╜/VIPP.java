package 享元模式;


public class VIPP extends Account {
    @Override
    public String getPermission() {
        return "身份：上帝用户";
    }
}
