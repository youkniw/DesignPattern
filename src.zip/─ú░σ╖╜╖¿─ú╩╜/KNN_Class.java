package 模板方法模式;

public class KNN_Class extends AbstractClass {
    @Override
    public void three() {
        System.out.println(" K 最近邻算法");
    }
}
