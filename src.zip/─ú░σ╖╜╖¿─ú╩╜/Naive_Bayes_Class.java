package 模板方法模式;

public class Naive_Bayes_Class extends AbstractClass {
    @Override
    public void three() {
        System.out.println("朴素贝叶斯分类算法");
    }
}
