package 模板方法模式;

public class Decision_Tree_Class extends AbstractClass{
    @Override
    public void three() {
        System.out.println("决策树分类算法");
    }
}
