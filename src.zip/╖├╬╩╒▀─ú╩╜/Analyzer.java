package 访问者模式;


public interface Analyzer {
    void analyze(Code code);
}
