package 桥接1;

/**
 * @Author Lang wenchong
 * @Date 2021/11/1 11:35
 * @Version 1.0
 */
public interface Filter {
    void beauty(String name);
}
