package 观察者模式;

public interface Observer {
    void handler(String msg);
}
