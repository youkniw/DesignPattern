package 工厂方法模式;

public interface ConnectionFactory {
    Connection buildConnection();
}

