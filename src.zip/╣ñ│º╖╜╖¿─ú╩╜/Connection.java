package 工厂方法模式;

public interface Connection {
   void connect();
}

