package 工厂方法模式;

public class HTTPConnectionFactory implements ConnectionFactory {
    @Override
    public Connection buildConnection() {
        return new HTTPConnection();
    }
}
