package 简单工厂模式;

public interface Shape {
    void draw();
    void erase();
}
