package 外观模式;

public class Image {
    public void save() {
        System.out.println("相册已完成备份");
    }
}
