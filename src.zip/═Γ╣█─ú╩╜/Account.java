package 外观模式;

public class Account {
    public void save() {
        System.out.println("通讯录已完成备份");
    }
}
