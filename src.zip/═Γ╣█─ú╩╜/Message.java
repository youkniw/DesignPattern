package 外观模式;

public class Message {
    public void save() {
        System.out.println("短信已完成备份");
    }
}
