package 策略模式;

public interface Strategy {
	public void algorithm();
}
