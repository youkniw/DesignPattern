package 策略模式;

public class PostCopyStrategy implements Strategy{
	@Override
	public void algorithm() {
		// TODO Auto-generated method stub
		System.out.println("Use PostCopyStrategy algorithm");
	}
}
