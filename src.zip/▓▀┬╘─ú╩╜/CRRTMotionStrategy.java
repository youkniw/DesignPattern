package 策略模式;

public class CRRTMotionStrategy implements Strategy {

	@Override
	public void algorithm() {
		// TODO Auto-generated method stub
		System.out.println("Use CR/RT-Motion algorithm");
	}

}
