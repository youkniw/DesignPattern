package 桥接模式;

public class TextureFilter implements Filter{
	@Override
	public void addFilter() {
		// TODO Auto-generated method stub
		System.out.print("add Texture Filter");
	}
}
