package 桥接模式;

public class BlurFilter implements Filter {
	@Override
	public void addFilter() {
		// TODO Auto-generated method stub
		System.out.print("add Blur Filter");
	}
}
