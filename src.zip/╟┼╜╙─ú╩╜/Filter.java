package 桥接模式;

public interface Filter {
	public void addFilter();
}
