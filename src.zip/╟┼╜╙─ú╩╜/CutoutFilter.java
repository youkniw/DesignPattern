package 桥接模式;

public class CutoutFilter implements Filter{

	@Override
	public void addFilter() {
		// TODO Auto-generated method stub
		System.out.print("add Cutout Filter");
	}
	
}
