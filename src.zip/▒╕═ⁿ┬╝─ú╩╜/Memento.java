package 备忘录模式;


public interface Memento {

}
