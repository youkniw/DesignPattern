package 备忘录模式;


public class Note {
    private String msg;

    public Note() {

    }

    ;

    public Note(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
