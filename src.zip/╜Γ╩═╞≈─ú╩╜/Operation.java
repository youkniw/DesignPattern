package 解释器模式;


public interface Operation {
    void interpret(DBMS srcDB, DBMS desDB);
}
