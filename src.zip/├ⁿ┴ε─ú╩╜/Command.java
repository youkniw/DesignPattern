package 命令模式;


public interface Command {
    void execute();
}
