package 中介者模式;


public interface Mediator {
    void contact(String msg, SubSystem system);
}
