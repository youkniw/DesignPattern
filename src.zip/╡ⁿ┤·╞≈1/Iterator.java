package 迭代器1;


public interface Iterator {
    boolean hasNext();

    String next();
}
