package 装饰模式1;

/**
 * @Author Lang wenchong
 * @Date 2021/11/1 16:17
 * @Version 1.0
 */
public class ConcreteTable extends Table{

}
