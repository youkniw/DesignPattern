package 装饰模式1;

/**
 * @Author Lang wenchong
 * @Date 2021/11/1 15:59
 * @Version 1.0
 */
public abstract class Table {
    String content = "报表内容";
    

    public void diskplay() {
        System.out.println(content);
    }
}
