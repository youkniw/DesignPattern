package 抽象工厂模式;

public interface Connection {
    void connect();
}
