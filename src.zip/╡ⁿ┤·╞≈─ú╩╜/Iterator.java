package 迭代器模式;

public interface Iterator {
    public abstract  boolean hasNext();
    public abstract  Object next();
}