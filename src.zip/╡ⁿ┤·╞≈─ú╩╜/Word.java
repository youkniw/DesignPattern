package 迭代器模式;

public class Word {
    private String word;
    public Word(String word) {
        this.word = word;
    }
    public String getWord() {
        return word;
    }

}
