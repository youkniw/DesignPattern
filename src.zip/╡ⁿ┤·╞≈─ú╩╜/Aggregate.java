package 迭代器模式;

public interface Aggregate {
    public abstract Iterator iterator();
}
