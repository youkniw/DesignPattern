package 适配器模式.two;

public interface Target {
    String encodePwd(String password);
}
