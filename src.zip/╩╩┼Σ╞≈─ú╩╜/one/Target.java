package 适配器模式.one;

public interface Target {
    String encodePwd(String password);
}
